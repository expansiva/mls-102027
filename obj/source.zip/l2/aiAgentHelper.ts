/// <mls fileReference="_102027_/l2/aiAgentHelper.ts" enhancement="_blank"/>
import { msgAppendLongTermMemory } from '/_102036_/l2/shared/api.js';

/**
 * Helper function to collect all steps from a task in a flat array
 */
export const getAllSteps = (firstStep: mls.msg.AIPayload[] | undefined): mls.msg.AIPayload[] => {
  if (!firstStep || firstStep.length < 1) {
    return [];
  }
  const allSteps: mls.msg.AIPayload[] = [];
  const queue: mls.msg.AIPayload[] = [...firstStep];

  // BFS approach to collect all steps
  while (queue.length > 0) {
    const currentStep = queue.shift()!;
    allSteps.push(currentStep);

    // Add nextSteps to queue if they exist
    if (currentStep.nextSteps) {
      queue.push(...currentStep.nextSteps);
    }

    // Add steps from interaction.payload if they exist
    if (currentStep.interaction?.payload) {
      queue.push(...currentStep.interaction.payload);
    }
  }

  return allSteps;
};

export const getAgentStepByAgentName = (task: mls.msg.TaskData, agentName: string): mls.msg.AIPayload | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.find((step): step is mls.msg.AIAgentStep => step.type === 'agent' && step.agentName === agentName);
  return agentSteps || null;
};

export const getAllAgentStepByAgentName = (task: mls.msg.TaskData, agentName: string): mls.msg.AIPayload[] | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIAgentStep => step.type === 'agent' && step.agentName === agentName);
  return agentSteps || null;
};

export const getAgentsStepByAgentName = (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus): mls.msg.AIPayload[] => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIAgentStep => step.type === 'agent' && step.agentName === agentName);
  if (!status) return agentSteps || [];
  return agentSteps.filter(step => step.status === status);
};


export const getStepById = (task: mls.msg.TaskData, stepId: number): mls.msg.AIPayload | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  return allSteps.find(step => step.stepId === stepId) || null;
};

export const getNextPendentStep = (task: mls.msg.TaskData): mls.msg.AIPayload | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  return allSteps.find(step => step.status === 'pending') || null;
};

export const getNextResultStep = (task: mls.msg.TaskData): mls.msg.AIResultStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIResultStep => step.type === 'result');
  return agentSteps.find(step => step.status === 'completed') || null;
}

export const getNextClarificationStep = (task: mls.msg.TaskData): mls.msg.AIClarificationStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIClarificationStep => step.type === 'clarification');
  return agentSteps.find(step => step.status === 'pending' || step.status === 'in_progress') || null;
}

export const getNextPendingStepByAgentName = (task: mls.msg.TaskData, agentName: string): mls.msg.AIAgentStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIAgentStep => step.type === 'agent');
  return agentSteps.find(step => step.status === 'pending' && step.agentName === agentName) || null;
}

export const getNextFlexiblePendingStep = (task: mls.msg.TaskData): mls.msg.AIFlexibleResultStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIFlexibleResultStep => step.type === 'flexible');
  return agentSteps.find(step => step.status === 'pending') || null;
}

export const getNextInProgressStepByAgentName = (task: mls.msg.TaskData, agentName: string): mls.msg.AIAgentStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIAgentStep => step.type === 'agent');
  return agentSteps.find(step => step.status === 'in_progress' && step.agentName === agentName) || null;
}

export const getRootAgent = (task: mls.msg.TaskData): mls.msg.AIAgentStep | null => {
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  const agentSteps = allSteps.filter((step): step is mls.msg.AIAgentStep => step.type === 'agent');
  return agentSteps[0] || null;
}

export const getInteractionStepId = (task: mls.msg.TaskData, stepId: number): number | null => {
  // nextSteps []
  // | interaction
  // | | nextsSteps []
  // ...
  // this routine finds the parent agent stepId for a pending step
  const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
  if (!allSteps) return null;

  for (const step of allSteps) {
    if (step.nextSteps?.find(s => s.stepId === stepId)) return step.stepId;
    if (!step.interaction || !step.interaction.payload) continue;
    if (step.interaction.payload.length < 1) continue;
    if (step.interaction.payload.find(s => s.stepId === stepId)) return step.stepId;
  }

  return null;
}

export type StatisticsAITask = {
  agents: number, tools: number, clarification: number, result: number, flexible: number,
  totalCost: number, totalSteps: number,
};

export const calculateStepsStatistics = (steps: mls.msg.AIPayload[], removeFirstStep: boolean): StatisticsAITask => {
  const allSteps = getAllSteps(steps);
  if (removeFirstStep) allSteps.shift();

  return {
    agents: allSteps.filter(step => step.type === 'agent').length,
    tools: allSteps.filter(step => step.type === 'tool').length,
    clarification: allSteps.filter(step => step.type === 'clarification').length,
    result: allSteps.filter(step => step.type === 'result').length,
    flexible: allSteps.filter(step => step.type === 'flexible').length,
    totalCost: allSteps.reduce((sum, step) => sum + (step.interaction?.cost || 0), 0),
    totalSteps: allSteps.length
  };
};

export const calculateStepsByFilter = (task: mls.msg.TaskData, filter: Record<string, any>): number => {
  const allSteps: mls.msg.AIPayload[] = getAllSteps(task.iaCompressed?.nextSteps);
  // example: calculateStepsByFilter(task, { toolName: "abc "})
  let result = 0;
  for (const step of allSteps) {
    let allPropertiesMatch: boolean = true;
    for (const [key, value] of Object.entries(filter)) {
      const value2 = (step as any)[key];
      if (value2 !== value) {
        allPropertiesMatch = false;
        break; // exit for
      }
    }
    if (allPropertiesMatch) result += 1;
  }
  return result;
};

export const getTemporaryContext = (threadId: string, userId: string, prompt: string): mls.msg.ExecutionContext => {
  // create temporary context

  const now = new Date();
  const formattedDate = now.getFullYear().toString()
    + String(now.getMonth() + 1).padStart(2, '0')
    + String(now.getDate()).padStart(2, '0')
    + String(now.getHours() + 3).padStart(2, '0')
    + String(now.getMinutes()).padStart(2, '0')
    + String(now.getSeconds()).padStart(2, '0')
    + "." + Math.floor(1000 + Math.random() * 9000);

  const context: mls.msg.ExecutionContext = {
    task: undefined,
    message: {
      threadId: threadId,
      orderAt: "",
      createAt: formattedDate,
      senderId: userId,
      content: prompt.trim(),
    },
    isTest: false
  };
  return context;
};

/** Browser: window.top ?? window. CLI/Deno: no-op (no window). */
function collabScopeWindow(): Window | undefined {
  if (typeof window === "undefined") return undefined;
  return window.top ? window.top : window;
}

function dispatchCollabEvent(name: string, detail: unknown): void {
  const scopeWindow = collabScopeWindow();
  if (!scopeWindow) return;
  scopeWindow.dispatchEvent(new CustomEvent(name, { detail, bubbles: true, composed: true }));
}

export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void {
  dispatchCollabEvent('message-send', { context });
}

export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void {
  dispatchCollabEvent('task-change', { context, oldContextCreateAt });
}

export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void {
  dispatchCollabEvent('task-completed', { context, result });
}

export function notifyThreadChange(thread: mls.msg.Thread): void {
  dispatchCollabEvent('thread-change', thread);
}

export function notifyMessageChange( message: mls.msg.Message): void {
  dispatchCollabEvent('message-change', message);
}


export function notifyThreadCreate(thread: mls.msg.Thread): void {
  dispatchCollabEvent('thread-create', thread);
}

export function dispatchDetailsTaskClose(taskId: string): void {
  dispatchCollabEvent('task-details-close', taskId);
}


export function getTotalCost(task: mls.msg.TaskData): string {
  let tot = 0;
  const nextSteps = task.iaCompressed?.nextSteps;
  if (!nextSteps || nextSteps.length === 0) return "$ 0.01"; // garante saída mínima

  const sumCosts = (payload: mls.msg.AIPayload[]) => {
    payload.forEach((pay) => {
      const { interaction, nextSteps } = pay;

      if (interaction) {
        tot += interaction.cost ? interaction.cost : 0;
        if (interaction.payload) sumCosts(interaction.payload);
      }

      if (nextSteps) {
        nextSteps.forEach((next) => sumCosts([next]));
      }
    });
  };

  nextSteps.forEach((step) => sumCosts([step]));

  const rounded = Math.ceil(tot * 100) / 100;
  return `${rounded.toFixed(2)}`;
}

export async function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>) {
  if (!context.task) throw new Error('[appendLongTermMemory] invalid task');
  const messageId: string | undefined = context.task.messageid_created;
  if (!messageId) throw new Error("[appendLongTermMemory] Invalid messageId");

  try {
    const ret = await msgAppendLongTermMemory({
      longTermMemory,
      messageId,
      taskId: context.task.PK,
      userId: context.message.senderId,
    });

    if (!ret || ret.statusCode !== 200) throw new Error("error on AI appendLongTermMemory , stoped");
    return (ret as mls.msg.ResponseAppendLongTermMemory).task;
  } catch (err: any) {
    throw new Error('[appendLongTermMemory] ' + err.message);
  }

}


export function getNextStepIdAvaliable(task: mls.msg.TaskData): number {

  let nextStepId = 0;
  const nextSteps = task.iaCompressed?.nextSteps;
  if (!nextSteps || nextSteps.length === 0) return nextStepId + 1;

  const findNextStepId = (payload: mls.msg.AIPayload[]) => {
    payload.forEach((pay) => {
      const { interaction, nextSteps, stepId } = pay;
      if (stepId > nextStepId) nextStepId = stepId + 1;
      if (interaction) {
        if (interaction.payload) findNextStepId(interaction.payload);
      }
      if (nextSteps) {
        nextSteps.forEach((next) => {
          if (next.stepId > nextStepId) nextStepId = next.stepId + 1;
          findNextStepId([next])
        });
      }

    });
  };

  nextSteps.forEach((step) => {
    if (step.stepId > nextStepId) nextStepId = step.stepId + 1;
    findNextStepId([step]);
  });
  return nextStepId;
}

export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep:number): mls.msg.AIAgentStep | null  {
  const nextSteps = data.iaCompressed?.nextSteps;

  // Percorre a árvore guardando o "pai" de cada stepId
  const traverse = (steps:any[], parentStep:mls.msg.AIAgentStep | null = null): mls.msg.AIAgentStep | undefined | null => {
    for (const step of steps) {
      if (step.type === "agent") {
        if (step.stepId === baseStep) {
          return parentStep;
        }

        // Busca recursiva nos nextSteps do step atual
        if (step.nextSteps && step.nextSteps.length > 0) {
          const found = traverse(step.nextSteps, step);
          if (found !== undefined) return found;
        }

        // Busca dentro do payload da interação (se existir e for objeto/array)
        if (step.interaction?.payload) {
          const payload = step.interaction.payload;
          const payloadSteps = Array.isArray(payload) ? payload : [payload];
          const found = traverse(payloadSteps, step);
          if (found !== undefined) return found;
        }
      }
    }
    return undefined;
  }

  if (nextSteps === undefined) {
    return null; 
  }

  const previousStep = traverse(nextSteps);

  if (previousStep === undefined) {
    return null; 
  }

  return previousStep; // null = é root, objeto = step pai
}
