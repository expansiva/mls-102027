/// <mls fileReference="_102027_/l2/until.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];