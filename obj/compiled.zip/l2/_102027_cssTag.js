/// <mls shortName="cssTag" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=css-tag.d.ts.map
