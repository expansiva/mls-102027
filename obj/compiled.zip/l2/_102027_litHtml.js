/// <mls shortName="litHtml" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=lit-html.d.ts.map
