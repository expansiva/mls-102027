/// <mls shortName="isServer" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=is-server.d.ts.map
