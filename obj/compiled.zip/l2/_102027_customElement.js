/// <mls shortName="customElement" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=custom-element.d.ts.maps.d.ts.map
