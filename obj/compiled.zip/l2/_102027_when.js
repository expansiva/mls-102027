/// <mls shortName="when" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=when.d.ts.map
