declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { msgApplyIntents } from "_102036_/l2/shared/api";
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Browser keeps IndexedDB. CLI calls setOrchestrationStorage before loadAgent/pooling. */
    export type OrchestrationStorage = {
        addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
        getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
        getMessage(messageId: string): Promise<mls.msg.Message | undefined>;
        addPooling(pooling: {
            taskId: string;
            userId: string;
            startAt: string;
        }): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        /**
         * The browser (IndexedDB) returns the updated thread; a host with no thread cache returns
         * nothing. Declared as the type the consumer actually needs — `unknown` compiled here and
         * broke at the two call sites that hand the result to `notifyThreadChange`.
         */
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<mls.msg.Thread | undefined>;
    };
    export function setOrchestrationStorage(next: OrchestrationStorage | null): void;
    type ApplyIntentsFn = typeof msgApplyIntents;
    /** CLI injects Bearer POST /msg. Browser never calls this. */
    export function setApplyIntents(fn: ApplyIntentsFn | null): void;
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    type OrchestrationListener = (event: OrchestrationEvent) => void;
    /** CLI / tests. Browser never subscribes — executeBeforePrompt still swallows the stream. */
    export function subscribeOrchestrationEvents(listener: OrchestrationListener): () => void;
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102027_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class AiAgentDefaultFeedback102027 extends StateLitElement {
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
        private collab_bell;
        private collab_play;
        private collab_pause;
    }
}
declare module "_102029_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102029_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102027_/l2/codeLensLit" {
    export * from "_102029_/l2/codeLensLit";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
        country: string;
        svg: string;
    }
    /**
     * Resolves a language entry by BCP 47 code.
     * Tries an exact (case-insensitive) match first — e.g. "pt-BR" —
     * then falls back to the base language — e.g. "pt-AO" -> "pt".
     */
    export function findLanguageByCode(code: string): ICollabLanguage | undefined;
}
declare module "_102027_/l2/collabMonacoEditor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMonacoEditor extends StateLitElement {
        msize: string;
        mlsEditor: any;
        get isMls2(): boolean;
        render(): any;
        updated(changed: Map<PropertyKey, unknown>): void;
        private _onMsizeChange;
    }
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102027_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_102027_/l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed102027 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        private collab_chevron_right;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "_102027_/l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        private collab_chevron_down;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "_102027_/l2/defsAST" {
    export function parseDefsFile(source: string): {
        asis: mls.defs.AsIs;
        history: mls.defs.ChangeHistoryItem[];
        skill: string;
    };
    export function getAsis(source: string): mls.defs.AsIs;
    export function updateAsis(source: string, patch: DeepPartial<mls.defs.AsIs>): string;
    export function replaceAsis(source: string, value: mls.defs.AsIs): string;
    export function getHistory(source: string): mls.defs.ChangeHistoryItem[];
    export function addHistoryItem(source: string, item: mls.defs.ChangeHistoryItem): string;
    export function updateHistoryItem(source: string, version: number, patch: Partial<mls.defs.ChangeHistoryItem>): string;
    export function replaceHistory(source: string, value: mls.defs.ChangeHistoryItem[]): string;
    export function getSkill(source: string): string;
    export function updateSkill(source: string, value: string): string;
    type DeepPartial<T> = {
        [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
    };
    export function getMaterializeIndex(source: string): mls.defs.MaterializeIndex;
    export function replaceMaterializeIndex(source: string, value: mls.defs.MaterializeIndex): string;
    export function addMaterializeItem(source: string, item: mls.defs.MaterializeEntry): string;
    export function updateMaterializeItem(source: string, id: string, patch: Partial<mls.defs.MaterializeEntry>): string;
    export function removeMaterializeItem(source: string, id: string): string;
    export function getVariableText(source: string, varName: string): string;
    export function updateVariableText(source: string, varName: string, value: string): string;
    export function getVariableJson<T = unknown>(source: string, varName: string): T;
    export function updateVariableJson(source: string, varName: string, value: unknown): string;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    /**
     * Project design system — ROLE-BASED token vocabulary.
     * Migrated from the family-based model (text-primary-color, bg-secondary-color,
     * grey-color) to the canonical vocabulary of _102029_/l2/designSystemBase.ts
     * (MANDATORY_COLOR_ROLES / DEFAULT_TOKENS_TEMPLATE). See TASK-102027-ds-tokens-por-papel.md.
     *
     * Naming rules (color):
     *  - The name says WHERE the token is used; never infer it from the value. The
     *    role of an old token was read off the CSS PROPERTY it fed, not off its name.
     *  - Pairs travel together: whoever paints with button-primary-bg writes the
     *    label with button-primary-text; the same holds for status-*, nav-*, tooltip-*.
     *  - Surfaces: page-bg (page) > surface-bg (cards, panels, dropdowns) >
     *    surface-alt-bg (zebra rows, section headers, hover rows). Text on them is
     *    text-strong (titles), text-default (body), text-muted (secondary).
     *  - Charts use chart-series-1..6 ALWAYS in this fixed order (the order IS the
     *    colour-blindness safeguard); status-* is state only, never a series.
     *  - Every base has -hover/-focus/-disabled, and a _dark- twin per key.
     *
     * This entry is kept IDENTICAL to the ones in _100554_ and _100555_ — the three
     * carried the exact same family palette before the migration and render side by
     * side in the studio, so a different surface grey between them would show up as
     * a seam. 102027 itself consumes almost none of these tokens (12 uses, all in
     * aiAgentDefaultFeedback.less); the entry matters mostly because this is the lib
     * everyone else imports.
     *
     * Where the values came from:
     *  - page-bg / surface-bg both inherit bg-primary-color (#ffffff / #0d1117):
     *    the old model had no separate page token, and the page and its panels are
     *    painted with the same colour.
     *  - surface-alt-bg takes bg-secondary-color-LIGHTER in light (#F9F9F9) but
     *    _dark-bg-secondary-color in dark (#161b22): the old dark twin of the
     *    lighter family was #636363, a mid grey that cannot serve as a surface over
     *    a #0d1117 page.
     *  - In dark, text-strong comes from _dark-text-primary-color-LIGHTER and
     *    text-muted from _dark-text-primary-color-DARKER — in the dark the lightest
     *    tone is the title and the darkest is the secondary text, an inversion the
     *    family model could not express.
     *  - border-default is grey-color-dark/-darker and border-subtle is grey-color;
     *    the -hover/-focus/-disabled steps are derived, since the old grey scale had
     *    no states.
     *  - button-primary-bg is active-color (#1890FF), which also feeds selected-text,
     *    selected-border and focus-ring; info-color keeps its state reading
     *    (status-info-text) and paints primary buttons where it was a fill.
     *  - button-primary-text / button-danger-text are white in BOTH themes: the old
     *    _dark-bg-primary-color-lighter was #666666, unreadable over a blue button.
     *  - Roles with no origin in the old model (input-bg, selected-bg, status-*-bg,
     *    status-neutral-*, nav-*, overlay-backdrop-bg, tooltip-*, chart-series-*)
     *    kept the 102029 template defaults.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102027_/l2/propiertiesLit" {
    export * from "_102029_/l2/propiertiesLit";
}
declare module "_102027_/l2/enhancementAgent" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string) => Promise<string>;
}
declare module "_102029_/l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/validateLit" {
    export * from "_102029_/l2/validateLit";
}
declare module "_102029_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102027_/l2/processCssLit" {
    export * from "_102029_/l2/processCssLit";
}
declare module "_102027_/l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102027_/l2/enhancementLitService" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/enhancementStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export const getDesignDetails: (modelStyle: mls.editor.IModelStyle) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getLineSelectorByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
}
declare module "_102027_/l2/lessTokensCompletion" {
    /** The `@token` reference under `column` (1-based), or null. Exported for testing. */
    export function tokenAt(line: string, column: number): {
        name: string;
        start: number;
        end: number;
    } | null;
    /** Register the `.less` token providers once per page. Safe to call from every service instance. */
    export function registerLessTokenProviders(): void;
    /** Undo the registration (tests / teardown). */
    export function disposeLessTokenProviders(): void;
}
declare module "_102027_/l2/lessTokensCompletion.test" { }
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102027_/l2/libModel.test" { }
declare module "_102027_/l2/libNewProject" {
    export interface IProjectType {
        id: string;
        name: string;
        dependencies: number[];
        agent?: string;
    }
    export const projectTypes: IProjectType[];
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_l5Project: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build_old: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
    export const template_l2Project: {
        ext: string;
        template: string;
    };
    export const template_deps: {
        ext: string;
        template: string;
    };
    export const template_coreIndex: {
        ext: string;
        template: string;
    };
    export const template_ds: {
        ext: string;
        template: string;
    };
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102027_/l2/libStor.test" { }
declare module "_102027_/l2/libUnsplash.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libUnsplash" {
    export function getImages(query: string, actualPage: number, perPage: number): Promise<GetImagesResult>;
    export interface UnsplashImage {
        id: string;
        alt_description: string | null;
        urls: {
            raw: string;
            full: string;
            regular: string;
            small: string;
            thumb: string;
        };
    }
    interface GetImagesResult {
        currentPage: number;
        totalPages: number;
        totalResults: number;
        perPage: number;
        images: UnsplashImage[];
    }
    export interface UnsplashSearchResponse {
        total: number;
        total_pages: number;
        results: UnsplashImage[];
    }
}
declare module "_102027_/l2/pluginBase" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export abstract class PluginBase extends CollabLitElement {
        scope: string;
        abstract description: string;
        abstract getSvg(): TemplateResult;
    }
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_102027_/l2/previewBase" {
    export abstract class PreviewModeBase {
        protected level: string | undefined;
        protected iFrame: HTMLIFrameElement | undefined;
        protected isService: boolean;
        protected storFile: mls.stor.IFileInfo | undefined;
        constructor(_iFrame: HTMLIFrameElement, _level: string, _isService: boolean, _storFile: mls.stor.IFileInfo);
        abstract init(): Promise<void>;
    }
}
declare module "_102029_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102027_/l2/project" {
    export * from "_102029_/l2/project";
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/updateProduct.defs" {
    export const contractSpec: {
        interfaces: {
            PetshopProduct: {
                fields: ({
                    name: string;
                    type: string;
                    optional?: undefined;
                } | {
                    name: string;
                    type: string;
                    optional: boolean;
                })[];
            };
            PetshopGetProductParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopCategory: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopListCategoriesParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
        };
        enums: {
            PetshopAction: {
                values: {
                    key: string;
                    value: string;
                }[];
            };
        };
        types: {
            PetshopProductId: {
                definition: string;
            };
        };
        constants: {
            PETSHOP_API_VERSION: {
                type: string;
                value: string;
            };
        };
    };
    export const sharedSpec: {
        className: string;
        interfacesPath: string;
        interfaces: {
            PetshopProduct: {
                fields: ({
                    name: string;
                    type: string;
                    optional?: undefined;
                } | {
                    name: string;
                    type: string;
                    optional: boolean;
                })[];
            };
            PetshopGetProductParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopCategory: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
            PetshopListCategoriesParams: {
                fields: {
                    name: string;
                    type: string;
                }[];
            };
        };
        properties: {
            name: string;
            type: string;
            default: string;
            reflect: boolean;
        }[];
        states: ({
            name: string;
            type: string;
            default: any;
            reset: boolean;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: boolean;
            reset?: undefined;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: any[];
            reset?: undefined;
            interfaceGroup?: undefined;
            field?: undefined;
        } | {
            name: string;
            type: string;
            default: string;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        } | {
            name: string;
            type: string;
            default: number;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        } | {
            name: string;
            type: string;
            default: boolean;
            interfaceGroup: string;
            field: string;
            reset?: undefined;
        })[];
        actions: ({
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            useMock: boolean;
            bff: {
                fn: string;
                params: string;
                result: string;
                onStart: {
                    state: string;
                    value: string;
                }[];
                onSuccess: {
                    state: string;
                    value: string;
                }[];
                onError: {
                    state: string;
                    value: string;
                }[];
            };
            onStart?: undefined;
        } | {
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            bff: {
                fn: string;
                params: string;
                result: string;
                onStart: {
                    state: string;
                    value: string;
                }[];
                onSuccess: {
                    state: string;
                    value: string;
                }[];
                onError: {
                    state: string;
                    value: string;
                }[];
            };
            useMock?: undefined;
            onStart?: undefined;
        } | {
            trigger: {
                state: string;
                value: string;
            };
            method: string;
            bff: any;
            onStart: {
                state: string;
                value: string;
            }[];
            useMock?: undefined;
        })[];
        lifecycle: {
            connectedCallback: {
                dispatchAction: string[];
            };
        };
    };
    export const desktopLayoutSpec: {
        className: string;
        tagName: string;
        extends: string;
        styling: string;
        imports: {
            type: string;
            import: string;
            path: string;
        }[];
        render: {
            conditions: {
                if: string;
                return: string;
            }[];
            blocks: {
                loading: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        i18n?: undefined;
                    } | {
                        element: string;
                        class: string;
                        i18n: string;
                    })[];
                };
                error: {
                    element: string;
                    class: string;
                    children: ({
                        element: string;
                        class: string;
                        bind: string;
                        i18n?: undefined;
                        event?: undefined;
                    } | {
                        element: string;
                        class: string;
                        i18n: string;
                        event: {
                            on: string;
                            type: string;
                            state: string;
                            value: string;
                        };
                        bind?: undefined;
                    })[];
                };
                default: {
                    element: string;
                    class: string;
                    event: {
                        on: string;
                        type: string;
                        state: string;
                        value: string;
                        prevent: boolean;
                    };
                    children: ({
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            children: {
                                element: string;
                                class: string;
                                i18n: string;
                                input: {
                                    type: string;
                                    class: string;
                                    bind: string;
                                    event: {
                                        on: string;
                                        type: string;
                                        state: string;
                                        cast: string;
                                    };
                                };
                            }[];
                        }[];
                    } | {
                        element: string;
                        class: string;
                        children: {
                            element: string;
                            class: string;
                            i18n: string;
                            input: {
                                type: string;
                                class: string;
                                bind: string;
                                options: {
                                    source: string;
                                    value: string;
                                    label: string;
                                };
                                event: {
                                    on: string;
                                    type: string;
                                    state: string;
                                    cast: string;
                                };
                            };
                        }[];
                    } | {
                        element: string;
                        class: string;
                        children: ({
                            element: string;
                            class: string;
                            type: string;
                            i18n: string;
                            event: {
                                on: string;
                                type: string;
                                state: string;
                                value: string;
                            };
                            disabled?: undefined;
                        } | {
                            element: string;
                            class: string;
                            type: string;
                            i18n: string;
                            disabled: string;
                            event?: undefined;
                        })[];
                    })[];
                };
            };
        };
        i18n: {
            default: string;
            languages: string[];
            keys: string[];
        };
    };
    export const lessSpec: {
        tagName: string;
        layout: {
            type: string;
            columns: number;
            states: string[];
        };
        classes: {
            name: string;
            role: string;
            context: string;
        }[];
    };
    export const materializeIndex: mls.defs.MaterializeIndex;
}
declare module "_102027_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102027_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102027_/l2/wcTeste" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WcTeste100000 extends CollabLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102027_/l2/agents/skills/genTest" {
    export const skill = "\n    return only string 'genTest completed'\n";
}
declare module "_102027_/l2/agents/skills/jointendFields" {
    export const skill = "\n# Jointed Fields \u2014 UI Layout Skill\n\n**Style Name:** Jointed Fields\n**Also known as:** Conjoined Fields \u00B7 Fused Field Pair \u00B7 Borderless Split Input\n\n---\n\n## What Is It?\n\nJointed Fields is a form layout pattern that pairs two semantically related input fields in the same row by removing the margin between them and sharing a unified container border. Each field keeps its own inline label (positioned small, at the top-left inside the field) and its own validation logic, but visually the pair reads as a single cohesive unit. The result: a form with 18 fields feels like 9.\n\n---\n\n## Core Principles\n\n- **Pair by relationship** \u2014 only join fields with a natural sibling bond (e.g. First Name + Last Name, City + State, Check-in + Check-out).\n- **Label inside the field** \u2014 each field uses a small, muted label anchored at the top-left, above the typed value.\n- **No gap between joined fields** \u2014 the pair shares one outer border; only a thin internal vertical line separates them.\n- **Proportional widths** \u2014 do not force 50/50. Size each field to match the expected input length (e.g. Postal Code narrow, Address wide).\n- **Independent validation** \u2014 each field validates and shows errors on its own, without affecting the other.\n\n---\n\n## Anatomy\n\nThe group has a single rounded outer border. Inside, a vertical divider separates the two fields. Each cell contains a small label on top and the input value below. On focus, the outer border changes color to indicate the active state. On error, only the offending field changes background and label color; the error message appears below that specific cell.\n\n---\n\n## Common Field Pairings\n\n| Left Field      | Right Field      | Suggested Split |\n|-----------------|------------------|-----------------|\n| First Name      | Last Name        | 50 / 50         |\n| Phone           | Email            | 40 / 60         |\n| Check-in Date   | Check-out Date   | 50 / 50         |\n| Address         | Apartment/Suite  | 70 / 30         |\n| City            | State            | 65 / 35         |\n| Postal Code     | Country          | 30 / 70         |\n| Card Number     | Cardholder Name  | 50 / 50         |\n| Expiry Date     | CVV              | 60 / 40         |\n\n---\n\n## When to Use\n\nUse when fields share a clear data relationship and you want to reduce perceived form density. Avoid when fields are unrelated, when one requires a complex picker that disrupts the layout, or when the form is single-column on mobile.\n\n---\n\n## Responsive Behavior\n\nOn narrow viewports (mobile), jointed fields should stack vertically, reverting to individual full-width fields \u2014 each with its own border and label \u2014 so usability is not compromised.\n\n---\n\n## Accessibility Notes\n\n- Every input must have a programmatically associated label.\n- The focus ring should be visible on the group container when any child field is active.\n- Error messages must be linked to their input via aria-describedby.\n- Tab order must follow left-to-right, top-to-bottom reading sequence.\n- Never rely on color alone to communicate an error state.\n\n---\n\n## Summary\n\nJointed Fields leverages the Gestalt principle of proximity \u2014 elements with no gap between them are perceived as a single object. By removing margin between related fields and adding a shared border, users read two inputs as one unit, significantly reducing the cognitive weight of dense forms.\n";
}
declare module "_102027_/l2/plugins/pluginTestUtils" {
    /**
     * Where a test case can run:
     * - 'browser': needs real DOM/customElements (mounts the component, dispatches events, etc.).
     * - 'vscode': pure logic, runs without DOM (e.g. an exported function that only transforms data).
     * When in doubt, use 'browser' — it's the environment with full fidelity; 'vscode' is opt-in
     * only for logic proven to be DOM-independent.
     */
    export type TestEnv = 'browser' | 'vscode';
    export interface IPluginTestParams {
        input?: any;
        expected: any;
        /** When true, `compare` checks that `expected` is a subset of `actual` (useful for large/dynamic outputs). */
        contains?: boolean;
    }
    /**
     * Shape-compatible with `ICANTest` (tsTestAST.ts): same functionName/params pair,
     * with `env` added so the runner can decide where to execute each function.
     */
    export interface IPluginTestCase {
        functionName: string;
        env: TestEnv;
        params: IPluginTestParams[];
    }
    /** Sorts tests so 'browser' comes before 'vscode' — use before running a batch. */
    export function sortByEnvironment(tests: IPluginTestCase[]): IPluginTestCase[];
    export function isBrowser(): boolean;
    /**
     * Creates the element, applies properties, appends it to the document and waits for the first render.
     * Every call is tracked so `cleanup()` can remove it later — never forget to call cleanup().
     */
    export function mount<T extends HTMLElement = HTMLElement>(tag: string, props?: Record<string, any>): Promise<T>;
    /** Looks inside the shadow DOM if it exists, otherwise falls back to the light DOM (plugins vary between the two). */
    export function query(el: Element, selector: string): Element | null;
    /**
     * Replaces `mls.*` keys with mocked values; returns a function that restores the original state.
     * `cleanup()` also restores any pending override, so using only overrideMls is already safe
     * even if the test throws before manually calling the restorer.
     *
     * Several `mls.*` namespaces (e.g. `mls.stor`, and even leaves inside it like `mls.stor.getKeyToFiles`)
     * are exposed as getter-only accessors with no setter — a plain `mls.stor.getKeyToFiles = fn` throws
     * `Cannot set property getKeyToFiles of [object Object] which has only a getter`. To work regardless of
     * depth, every write goes through `Object.defineProperty` (which replaces the property descriptor
     * outright, bypassing the missing setter) instead of plain assignment.
     *
     * When both the current value and the override are plain objects, only the override's own keys are
     * replaced on the *existing* object — one level deep — instead of swapping the whole reference. E.g.
     * `overrideMls({ stor: { getKeyToFiles: fn } })` replaces just `mls.stor.getKeyToFiles`, leaving every
     * other property of the real `mls.stor` (and its many loaded files) untouched.
     */
    export function overrideMls(overrides: Record<string, any>): () => void;
    /** Removes every mounted element and undoes any pending `mls.*` overrides. Call at the end of each test (try/finally). */
    export function cleanup(): void;
    /**
     * Universal contract check (layer 1 of the strategy): element registered and renders without throwing.
     * Works for any of the 88 plugins, regardless of type.
     */
    export function mountAndVerify(tag: string, props?: Record<string, any>): Promise<{
        registered: boolean;
        rendered: boolean;
    }>;
    /**
     * Compares the actual value against the expected one (deep-equal with normalization) and throws
     * a formatted error on mismatch — keeps the "threw = failed" semantics of the ICAN runner.
     */
    export function compare(actual: any, expected: any, opts?: {
        contains?: boolean;
    }): void;
}
