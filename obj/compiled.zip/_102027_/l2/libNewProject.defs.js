"use strict";
/// <mls fileReference="_102027_/l2/libNewProject.defs.ts" enhancement="_blank"/>
//# sourceMappingURL=libNewProject.defs.js.map