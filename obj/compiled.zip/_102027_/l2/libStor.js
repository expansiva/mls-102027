/// <mls fileReference="_102027_/l2/libStor.ts" enhancement="_blank"/>
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
export async function createStorFile(req, needCreateModel, needCompile = true, awaitCompile = false) {
    const params = {
        project: req.project,
        level: req.level,
        shortName: req.shortName,
        extension: req.extension,
        versionRef: '0',
        folder: req.folder,
        updatedAt: new Date().toISOString()
    };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[createStorFile] Invalid storFile');
    file.status = req.status ?? 'new';
    let source = req.source;
    if (req.level === 2) {
        const { verifyNeedAddTripleslach } = await import('/_102027_/l2/libCommom.js');
        source = verifyNeedAddTripleslach(params, req.source, req.extension);
    }
    const fileInfo = {
        content: source,
        contentType: 'string'
    };
    if (req.fileInfo) {
        fileInfo.originalFolder = req.fileInfo.originalFolder;
        fileInfo.originalProject = req.fileInfo.originalProject;
        fileInfo.originalShortName = req.fileInfo.originalShortName;
    }
    await mls.stor.localStor.setContent(file, fileInfo);
    if (needCreateModel && ['.ts', '.html', '.defs.ts', '.test.ts'].includes(file.extension)) {
        const { createModel } = await import('/_102027_/l2/libModel.js');
        await createModel(file, needCompile, awaitCompile);
    }
    // file.getModel = async () => _getModel(file);
    return file;
}
export async function createAllFiles(req, needCreateModel = true, awaitCompile = false) {
    const { folder, shortName, project } = req;
    const { getBaseTemplate } = await import('/_102027_/l2/libCommom.js');
    const template = await getBaseTemplate({ folder, shortName, project, extension: '.ts' }, req.enhancement);
    const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
    const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
    const templateTest = await getBaseTemplate({ folder, shortName, project, extension: '.test.ts' });
    const templateDefs = await getBaseTemplate({ folder, shortName, project, extension: '.defs.ts' });
    const newTSSource = req.tsSource || template;
    const newHTMLSource = req.htmlSource || templateHTML;
    const newLessSource = req.lessSource || templateLess;
    const newTestSource = req.testSource || templateTest;
    const newDefsSource = req.defsSource || templateDefs;
    const param = {
        project: req.project,
        shortName: req.shortName,
        folder: req.folder,
        level: req.level,
        extension: '.ts',
        source: newTSSource,
        status: 'new'
    };
    const ret = {
        ts: await safeCreate(param, false)
    };
    ret.html = await safeCreate({ ...param, extension: '.html', source: newHTMLSource }, false);
    ret.less = await safeCreate({ ...param, extension: '.less', source: newLessSource }, false);
    ret.test = await safeCreate({ ...param, extension: '.test.ts', source: newTestSource }, false);
    ret.def = await safeCreate({ ...param, extension: '.defs.ts', source: newDefsSource }, false);
    if (needCreateModel && ret.ts && !(ret.ts instanceof Error)) {
        const { createAllModels } = await import('/_102027_/l2/libModel.js');
        await createAllModels(ret.ts, true, awaitCompile);
    }
    return ret;
}
function hostUnlink() {
    const fn = mls.stor.localStor.deleteFile;
    return typeof fn === 'function' ? fn : undefined;
}
export async function deleteFile(storFile) {
    const unlink = hostUnlink();
    if (unlink) {
        await unlink(storFile);
        if (storFile.status === 'deleted') {
            mls.events.fireFileAction('statusOrErrorChanged', storFile, 'left', 0);
            mls.events.fireFileAction('statusOrErrorChanged', storFile, 'right', 0);
        }
        return;
    }
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (storFile.getValueInfo) {
        let valueInfo = mls.editor.models[keyToModel] ? await storFile.getValueInfo() : {};
        if (!valueInfo.content) {
            const src = await storFile.getContent();
            valueInfo = {
                content: src,
                contentType: 'string',
                originalShortName: storFile.shortName,
                originalProject: storFile.project,
                originalCRC: mls.common.crc.crc32(src).toString(16)
            };
        }
        await mls.stor.localStor.setContent(storFile, valueInfo);
    }
    // Host setContent promotes status to `changed`. Mark deleted after the trash write so the
    // in-memory object stays deleted (getFileModified treats deleted as absent).
    storFile.status = 'deleted';
    mls.events.fireFileAction('statusOrErrorChanged', storFile, 'left', 0);
    mls.events.fireFileAction('statusOrErrorChanged', storFile, 'right', 0);
}
export async function deleteAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await deleteFile(mls.stor.files[key]);
    }
}
export async function removeNewStorFilesWithTemplateDefault() {
    const removed = [];
    const project = mls.actualProject;
    if (!project)
        return removed;
    // snapshot: deleteFile remove entradas de mls.stor.files durante o loop
    const files = Object.values(mls.stor.files).filter((f) => f && f.project === project && f.status === 'new');
    const { isStorContentEqualTemplateDefault } = await import('/_102027_/l2/libCommom.js');
    for await (const storFile of files) {
        const isTemplate = await isStorContentEqualTemplateDefault(storFile);
        if (!isTemplate)
            continue;
        await deleteFile(storFile); // status 'new' -> remoção real (deleteFileSystem)
        removed.push(storFile);
    }
    return removed;
}
export async function renameFile(storFile, newProject, newShortName, newFolder, needCompile = true) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[renameFile] Impossible rename this file:' + storFile.shortName);
    //if (!newFolder) newFolder = storFile.folder;
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: newFolder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: storFile.status === 'new' ? 'new' : 'renamed',
        fileInfo: {
            originalFolder: storFile.folder,
            originalProject: storFile.project,
            originalShortName: storFile.shortName
        }
    };
    const needCreateModels = param.level === 2;
    const file = await createStorFile(param, needCreateModels, needCompile);
    await deleteFileSystem(storFile);
    mls.events.fireFileAction('statusOrErrorChanged', file, 'left', 0);
    mls.events.fireFileAction('statusOrErrorChanged', file, 'right', 0);
    return file;
}
export async function renameAllFiles(storFile, newProject, newShortName, newFolder, needCompile = true) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts', '.json']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeRename(mls.stor.files[key], newProject, newShortName, newFolder, needCompile);
    }
    return ret;
}
export async function cloneFile(storFile, newProject, newShortName) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[cloneFile] Impossible rename this file:' + storFile.shortName);
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, storFile.folder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: storFile.folder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: 'new'
    };
    const file = await createStorFile(param, true);
    return file;
}
export async function cloneAllFiles(storFile, newProject, newShortName) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeClone(mls.stor.files[key], newProject, newShortName);
    }
    return ret;
}
export async function undoFile(storFile, removeProject = true) {
    storFile.getValueInfo = undefined;
    if (storFile.status === 'nochange' && !storFile.inLocalStorage) {
        return;
    }
    const draft = await draftUndoMode(storFile.project);
    if (draft.kind === 'broken') {
        showUndoError('driver', draft.detail);
        return;
    }
    if (draft.kind === 'on') {
        await undoFilePublished(storFile, draft.driver);
        return;
    }
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    if (storFile.status === 'deleted') {
        storFile.status = 'nochange';
    }
    if (storFile.status === 'renamed') {
        await undoFileRenamed(storFile);
        return;
    }
    if (storFile.status === 'changed') {
        storFile.status = 'nochange';
        storFile.inLocalStorage = false;
        storFile.hasError = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        if (storFile.isLocalVersionOutdated && storFile.newVersionRefIfOutdated) {
            storFile.versionRef = storFile.newVersionRefIfOutdated;
            storFile.isLocalVersionOutdated = false;
            storFile.newVersionRefIfOutdated = undefined;
        }
    }
    if (storFile.inLocalStorage) {
        storFile.inLocalStorage = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    }
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (!mls.editor.models[keyToModel])
        return;
    const prop = mapExtUndo[storFile.extension];
    if (prop && mls.editor.models[keyToModel]?.[prop]) {
        mls.editor.models[keyToModel][prop]?.model.dispose();
        delete mls.editor.models[keyToModel][prop];
    }
    if (removeProject && storFile)
        await mls.stor.localDB.removePrjInfo(storFile.project);
}
export async function undoAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await undoFile(mls.stor.files[key], false);
    }
    await mls.stor.localDB.removePrjInfo(storFile.project);
    const { createAllModels } = await import('/_102027_/l2/libModel.js');
    createAllModels(storFile, true, false, false);
}
function isNewNameValid(newShortName) {
    if (newShortName.length === 0 || newShortName.length > 255)
        return false;
    const invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
    return (!invalidCharacters.test(newShortName));
}
//---------AUXILIARY FUNCTIONS AND DEFINITIONS-------------
const mapExt = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'less',
    '.test.ts': 'test',
    '.defs.ts': 'def'
};
const mapExtUndo = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'style',
    '.test.ts': 'test',
    '.defs.ts': 'defs'
};
export function replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, src) {
    const { folder, project, shortName, level, extension } = storFile;
    const oldTag = convertFileNameToTag({ folder, project, shortName });
    const newTag = convertFileNameToTag({ folder: newFolder, project: newProject, shortName: newShortName });
    const fileReference = `_${newProject}_/l${level}/${newFolder ? newFolder + '/' : ''}${newShortName}${extension}`;
    const regex = new RegExp(oldTag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    src = src.replace(/fileReference="[^"]*"/, `fileReference="${fileReference}"`).replace(/shortName="[^"]*"/, `shortName="${newShortName}"`).replace(/project="[^"]*"/, `project="${newProject}"`).replace(/folder="[^"]*"/, `folder="${newFolder}"`);
    return src.replace(regex, newTag);
}
async function deleteFileSystem(storFile) {
    //mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true, storFile.level);
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    if (mls.editor.models[keyToModel]) {
        const prop = mapExtUndo[storFile.extension];
        if (prop && mls.editor.models[keyToModel]?.[prop]) {
            mls.editor.models[keyToModel][prop]?.model.dispose();
            delete mls.editor.models[keyToModel][prop];
        }
    }
    const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    delete mls.stor.files[keyFiles];
}
async function safeCreate(param, createMdl) {
    try {
        return await createStorFile(param, createMdl);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeRename(storFile, newProject, newShortName, newFolder, needCompile = true) {
    try {
        return await renameFile(storFile, newProject, newShortName, newFolder, needCompile);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeClone(storFile, newProject, newShortName) {
    try {
        return await cloneFile(storFile, newProject, newShortName);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function undoFileRenamed(storFile) {
    if (!storFile.getValueInfo && mls.stor.localDB.getContentInfoOrNull)
        storFile.getValueInfo = mls.stor.localDB.getContentInfoOrNull;
    const info = storFile.getValueInfo ? await storFile.getValueInfo() : {};
    if (!info.originalProject || !info.originalShortName)
        throw new Error('[undoFileRenamed] Not found info base for rename');
    const originalKey = mls.stor.getKeyToFiles(info.originalProject, storFile.level, info.originalShortName, info.originalFolder || storFile.folder, storFile.extension);
    const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    if (!mls.stor.files[originalKey]) {
        const params = {
            project: info.originalProject,
            level: storFile.level,
            shortName: info.originalShortName,
            extension: storFile.extension,
            versionRef: '0',
            folder: info.originalFolder || storFile.folder
        };
        await mls.stor.addOrUpdateFile(params);
    }
    if (mls.stor.files[key]) {
        await mls.stor.localStor.setContent(mls.stor.files[key], { contentType: 'string', content: null });
        delete mls.stor.files[key];
    }
}
// Draft undo restores the published blob. The open Monaco model keeps that text;
// disposing it (the non-draft path) would show the draft again on the next read.
const UNDO_TEXT = {
    en: {
        read: 'Could not read the published version.',
        save: 'Could not write the published version to the draft.',
        main: 'The published commit is unknown, so the file stays as it is.',
        name: 'The published name is missing, so the file stays as it is.',
        driver: 'The draft driver failed, so the file stays as it is.',
    },
    pt: {
        read: 'Não foi possível ler a versão publicada.',
        save: 'Não foi possível gravar a versão publicada no rascunho.',
        main: 'O commit publicado é desconhecido, então o arquivo permanece como está.',
        name: 'O nome publicado está ausente, então o arquivo permanece como está.',
        driver: 'O driver do rascunho falhou, então o arquivo permanece como está.',
    },
};
function undoErrorText(err) {
    return err instanceof Error ? err.message : String(err);
}
function undoSentence(key) {
    const raw = typeof document === 'undefined' ? 'en' : (document.documentElement?.lang || 'en');
    const lang = raw.toLowerCase().startsWith('pt') ? 'pt' : 'en';
    return UNDO_TEXT[lang][key];
}
function showUndoError(key, detail) {
    const sentence = undoSentence(key);
    console.error(`[undoFile] ${sentence} ${detail}`);
    const screen = globalThis.collabMessages;
    if (!screen || typeof screen.add !== 'function') {
        console.error('[undoFile] collabMessages is missing; the error stayed off the screen');
        return;
    }
    screen.add(sentence, 'error');
}
function isDraftHistoryDriver(value) {
    if (typeof value !== 'object' || value === null)
        return false;
    return typeof value.getHistoryContent === 'function';
}
function siteMode() {
    const getMode = mls.sites?.getMode;
    return typeof getMode === 'function' ? getMode() : undefined;
}
async function draftUndoMode(project) {
    // Production, or a host that never registered getMode: keep the pre-draft undo.
    // Do not import the studio module (this file also runs in the collabmsg host,
    // which has no studio bundle).
    if (siteMode() !== 'studio')
        return { kind: 'off' };
    try {
        const { activeDraft, isVmDriver } = await import('/_102033_/l2/cbe/studioDraft.js');
        const draft = activeDraft();
        if (!draft) {
            console.error('[undoFile] studio mode has no active draft');
            return { kind: 'off' };
        }
        const others = mls.stor.others;
        if (!others || typeof others.getDefaultDriver !== 'function') {
            return { kind: 'broken', detail: 'getDefaultDriver is missing' };
        }
        const driver = await others.getDefaultDriver(project);
        if (!isVmDriver(driver))
            return { kind: 'off' };
        if (!isDraftHistoryDriver(driver))
            return { kind: 'broken', detail: 'getHistoryContent is missing' };
        return { kind: 'on', driver };
    }
    catch (err) {
        return { kind: 'broken', detail: undoErrorText(err) };
    }
}
async function publishedText(driver, fileInfo, main) {
    let content;
    try {
        content = await driver.getHistoryContent(fileInfo, main);
    }
    catch (err) {
        showUndoError('read', undoErrorText(err));
        return undefined;
    }
    if (typeof content !== 'string') {
        showUndoError('read', 'getHistoryContent returned nothing');
        return undefined;
    }
    return content;
}
function contentsRejected(result) {
    if (result === false || result === undefined || result === null)
        return true;
    if (!Array.isArray(result))
        return false;
    return result.some((row) => {
        if (typeof row !== 'object' || row === null)
            return false;
        return row.result === false;
    });
}
async function saveDraftContents(files) {
    if (typeof mls.stor.setContents !== 'function') {
        showUndoError('save', 'setContents is missing');
        return false;
    }
    try {
        const saved = await mls.stor.setContents(files, null);
        if (contentsRejected(saved)) {
            showUndoError('save', 'setContents rejected the write');
            return false;
        }
        return true;
    }
    catch (err) {
        showUndoError('save', undoErrorText(err));
        return false;
    }
}
function fileKeyOf(storFile) {
    return mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
}
async function putPublishedContent(storFile, published) {
    const value = { contentType: 'string', content: published };
    storFile.inLocalStorage = true;
    await mls.stor.localStor.setContent(storFile, value);
    storFile.getValueInfo = () => Promise.resolve(value);
    // `deleted` would make setContents remove the path. A write needs any other status.
    storFile.status = 'changed';
}
function finishPublished(storFile) {
    storFile.status = 'nochange';
    storFile.inLocalStorage = false;
    storFile.hasError = false;
}
async function showPublished(storFile, published) {
    let crcSrc = published;
    if (storFile.extension === '.less') {
        try {
            const { removeTokensFromSource } = await import('/_102027_/l2/libCompileStyle.js');
            crcSrc = removeTokensFromSource(published).trim();
        }
        catch (err) {
            console.error(`[undoFile] less crc: ${undoErrorText(err)}`);
        }
    }
    const key = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder, storFile.level);
    const bucket = mls.editor.models[key];
    if (!bucket)
        return;
    const prop = mapExtUndo[storFile.extension];
    const slot = prop ? bucket[prop] : undefined;
    if (!slot?.model || typeof slot.model.setValue !== 'function') {
        console.error(`[undoFile] ${storFile.shortName}: open model has no setValue`);
        return;
    }
    slot.model.setValue(published);
    if (typeof mls.common?.crc?.crc32 === 'function')
        slot.originalCRC = mls.common.crc.crc32(crcSrc).toString(16);
}
async function undoFilePublished(storFile, driver) {
    const { draftPublishedCommit } = await import('/_102033_/l2/cbe/studioDraftFiles.js');
    const main = draftPublishedCommit();
    if (!main) {
        showUndoError('main', 'draftDiff did not store main');
        return;
    }
    if (storFile.status === 'new') {
        const previous = storFile.status;
        storFile.status = 'deleted';
        const saved = await saveDraftContents([storFile]);
        if (!saved) {
            storFile.status = previous;
            return;
        }
        await deleteFileSystem(storFile);
        return;
    }
    if (storFile.status === 'renamed') {
        await undoPublishedRenamed(storFile, driver, main);
        return;
    }
    const published = await publishedText(driver, storFile, main);
    if (published === undefined)
        return;
    const key = fileKeyOf(storFile);
    const wasIn = Object.prototype.hasOwnProperty.call(mls.stor.files, key);
    const previous = storFile.status;
    mls.stor.files[key] = storFile;
    await putPublishedContent(storFile, published);
    const saved = await saveDraftContents([storFile]);
    if (!saved) {
        storFile.status = previous;
        if (!wasIn)
            delete mls.stor.files[key];
        return;
    }
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    finishPublished(storFile);
    await showPublished(storFile, published);
}
function publishedOrigin(storFile) {
    const db = mls.stor.localDB;
    const reader = db?.getContentInfoOrNull;
    if (!storFile.getValueInfo && typeof reader === 'function') {
        storFile.getValueInfo = reader;
    }
    return storFile.getValueInfo ? storFile.getValueInfo() : Promise.resolve({});
}
async function undoPublishedRenamed(storFile, driver, main) {
    const info = await publishedOrigin(storFile);
    if (!info.originalProject || !info.originalShortName) {
        showUndoError('name', storFile.shortName);
        return;
    }
    const originalFolder = info.originalFolder || storFile.folder;
    const originalKey = mls.stor.getKeyToFiles(info.originalProject, storFile.level, info.originalShortName, originalFolder, storFile.extension);
    const probe = {
        ...storFile,
        project: info.originalProject,
        shortName: info.originalShortName,
        folder: originalFolder,
        status: 'changed',
    };
    const published = await publishedText(driver, probe, main);
    if (published === undefined)
        return;
    const existed = Boolean(mls.stor.files[originalKey]);
    if (!existed) {
        const created = await mls.stor.addOrUpdateFile({
            project: info.originalProject,
            level: storFile.level,
            shortName: info.originalShortName,
            extension: storFile.extension,
            versionRef: '0',
            folder: originalFolder,
        });
        if (!created && !mls.stor.files[originalKey]) {
            showUndoError('save', 'addOrUpdateFile did not restore the published name');
            return;
        }
    }
    const original = mls.stor.files[originalKey] ?? probe;
    await putPublishedContent(original, published);
    const previous = storFile.status;
    storFile.status = 'deleted';
    const saved = await saveDraftContents(original.project === storFile.project ? [original, storFile] : [original]);
    if (!saved) {
        storFile.status = previous;
        if (!existed)
            delete mls.stor.files[originalKey];
        return;
    }
    if (original.project !== storFile.project) {
        const removed = await saveDraftContents([storFile]);
        if (!removed) {
            storFile.status = previous;
            return;
        }
    }
    await mls.stor.localStor.setContent(original, { contentType: 'string', content: null });
    finishPublished(original);
    await showPublished(original, published);
    await showPublished(storFile, published);
    const newKey = fileKeyOf(storFile);
    if (newKey !== originalKey && mls.stor.files[newKey]) {
        await mls.stor.localStor.setContent(mls.stor.files[newKey], { contentType: 'string', content: null });
        delete mls.stor.files[newKey];
    }
}
