/// <mls fileReference="_102027_/l2/litElement.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
