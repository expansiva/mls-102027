/// <mls fileReference="_102027_/l2/isServer.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=is-server.d.ts.map
