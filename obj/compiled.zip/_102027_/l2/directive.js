/// <mls fileReference="_102027_/l2/directive.ts" enhancement="_blank" />
export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from '/_102027_/l2/litHtml.js';
