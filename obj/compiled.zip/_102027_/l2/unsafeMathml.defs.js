"use strict";
/// <mls fileReference="_102027_/l2/unsafeMathml.defs.ts" enhancement="_blank" />
//# sourceMappingURL=unsafeMathml.defs.js.map