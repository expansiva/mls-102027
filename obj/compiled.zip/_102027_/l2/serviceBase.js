/// <mls fileReference="_102027_/l2/serviceBase.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { StateLitElement } from '../../_102029_/l2/stateLitElement.js';
import { customElement, property, state } from 'lit/decorators.js';
import * as libCommom from './libCommom.js';
let ServiceBase = class ServiceBase extends StateLitElement {
    constructor() {
        super(...arguments);
        this.position = 'left';
        this.visible = 'false';
        this.msize = '';
        this.loading = false;
        this.loadingFeedBack = '';
    }
    get level() { return +(this.getAttribute('level') || 7); }
    ;
    get serviceContent() {
        if (this._serviceContent === undefined) {
            this._serviceContent = this.getNav3ServiceContent();
        }
        return this._serviceContent;
    }
    get nav3Service() {
        if (this._nav3Service === undefined) {
            this._nav3Service = this.getNav3Service();
        }
        return this._nav3Service;
    }
    get nav3Menu() {
        return this.getNav3ServiceMenu();
    }
    get serviceItemNav() {
        this._serviceItemNav = this.getServiceItemNav();
        return this._serviceItemNav;
    }
    get tooltipEl() {
        if (this._tooltipEl === undefined) {
            this._tooltipEl = this.getTooltip();
        }
        return this._tooltipEl;
    }
    getActualRef() {
        return this.nav3Service?.getAttribute('data-service') || '';
    }
    setError(error) {
        const nav3Service = this.getNav3Service();
        if (!nav3Service)
            return;
        nav3Service['serviceBind'] = this.details.widget;
        nav3Service.setAttribute('error', error);
    }
    toogleBadge(show, serviceName, saveState = true) {
        const mlsNav2 = this.getMlsNav2();
        if (!mlsNav2) {
            console.error('Function toogleBadge: mls-nav-2 dont exist');
            return;
        }
        mlsNav2.toogleBadge(show, serviceName, saveState);
    }
    openMe() {
        const itemService = this.serviceItemNav;
        if (itemService)
            itemService.click();
    }
    showNav2Item(show) {
        const itemService = this.serviceItemNav;
        if (itemService && itemService.show)
            itemService.show(show);
    }
    openService(service, position, level, args) {
        libCommom.openService(service, position, level, args);
    }
    setFullScreen(level, position) {
        const spliter = this.getSplitter();
        if (!spliter)
            return;
        spliter.setFullScreen(level, position);
    }
    selectLevel(level) {
        libCommom.selectLevel(level);
    }
    connectedCallback() {
        super.connectedCallback();
        this['mlsWidget'] = this;
        this.serviceContent?.addEventListener('focusin', this.checkFocus.bind(this));
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'visible') {
            const visible = newVal === 'true';
            const reinit = oldVal !== null && visible !== false;
            if (this.onServiceClick && typeof this.onServiceClick === 'function') {
                const nav3 = this.getNav3ServiceContent();
                if (nav3)
                    nav3.layout(); // resize
                this.onServiceClick(visible, reinit, nav3);
            }
        }
        if (name === 'msize') {
            const [width, height, top, left] = this.msize.split(',');
            if (height)
                this.style.height = height + 'px';
            this.style.overflow = 'auto';
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('loading')) {
            const loading = changedProperties.get('loading');
            if (loading !== undefined) {
                const nav3Service = this.getNav3Service();
                if (!nav3Service)
                    return;
                nav3Service['serviceBind'] = this.details.widget;
                nav3Service.setAttribute('loading', (!loading).toString());
            }
        }
        if (changedProperties.has('loadingFeedBack')) {
            const loadingFeedBack = changedProperties.get('loadingFeedBack');
            if (loadingFeedBack !== undefined) {
                const nav3Service = this.getNav3Service();
                if (!nav3Service)
                    return;
                nav3Service.setAttribute('loadingFeedBack', this.loadingFeedBack);
            }
        }
    }
    checkFocus() {
        if (!this.serviceContent)
            return;
        if (this.serviceContent.contains(document.activeElement)) {
            this.setActualServicePosition();
        }
    }
    setActualServicePosition() {
        if (!this.serviceContent || !this.nav3Service)
            return;
        const service = this.serviceContent.getAttribute('data-service') || '';
        const position = this.nav3Service.getAttribute('toolbarposition') || '';
        mls.setActualPosition(position);
        mls.setActualService(service);
    }
    getMlsNav2() {
        const mlsNav2 = this.closest('collab-nav-3')?.previousElementSibling;
        return mlsNav2;
    }
    getNav3ServiceContent() {
        const parentToolbarContent = this.closest('collab-nav-3-service');
        return parentToolbarContent;
    }
    getNav3Service() {
        const parentToolbarContent = this.closest('collab-nav-3');
        return parentToolbarContent;
    }
    getNav3ServiceMenu() {
        const content = this.getNav3ServiceContent();
        if (!content)
            return null;
        let nav3Menu = content.querySelector('mls-nav3-100529');
        if (!nav3Menu)
            nav3Menu = content.querySelector('collab-nav-3-menu');
        return nav3Menu;
    }
    getTooltip() {
        const tooltip = document.querySelector('collab-tooltip');
        return tooltip;
    }
    getSplitter() {
        const tooltip = this.closest('collab-spliter');
        return tooltip;
    }
    getServiceItemNav() {
        const toolbar = this.getMlsNav2();
        if (!toolbar)
            return null;
        const content = this.getNav3ServiceContent();
        if (!content)
            return null;
        const dataservice = content.getAttribute('data-service');
        const item = toolbar.querySelector(`collab-nav-2-item[data-service="${dataservice}"]`);
        return item;
    }
};
__decorate([
    property({ type: String, reflect: true })
], ServiceBase.prototype, "position", void 0);
__decorate([
    property({ type: String, noAccessor: true })
], ServiceBase.prototype, "visible", void 0);
__decorate([
    property({ type: String, noAccessor: true })
], ServiceBase.prototype, "msize", void 0);
__decorate([
    state()
], ServiceBase.prototype, "loading", void 0);
__decorate([
    state()
], ServiceBase.prototype, "loadingFeedBack", void 0);
ServiceBase = __decorate([
    customElement('service-base-102027')
], ServiceBase);
export { ServiceBase };
//# sourceMappingURL=serviceBase.js.map