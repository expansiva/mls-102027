/// <mls fileReference="_102027_/l2/plugins/pluginTestUtils.ts" enhancement="_102027_/l2/enhancementLit" />
const ORDEM_ENV = { browser: 0, vscode: 1 };
/** Ordena testes priorizando 'browser' antes de 'vscode' — usar antes de executar em lote. */
export function ordenarPorAmbiente(testes) {
    return [...testes].sort((a, b) => ORDEM_ENV[a.env] - ORDEM_ENV[b.env]);
}
export function isBrowser() {
    return typeof window !== 'undefined' && typeof document !== 'undefined' && typeof customElements !== 'undefined';
}
const elementosMontados = [];
const mlsBackup = [];
/**
 * Cria o elemento, aplica propriedades, anexa ao document e espera o primeiro render.
 * Cada chamada fica registrada para `cleanup()` remover depois — nunca esqueça de chamar cleanup().
 */
export async function mount(tag, props = {}) {
    if (!isBrowser())
        throw new Error(`mount('${tag}') exige ambiente browser (env: 'browser')`);
    const el = document.createElement(tag);
    Object.assign(el, props);
    document.body.appendChild(el);
    elementosMontados.push(el);
    if ('updateComplete' in el)
        await el.updateComplete;
    return el;
}
/** Busca no shadow DOM se existir, senão cai para o light DOM (plugins variam entre os dois). */
export function query(el, selector) {
    return el.shadowRoot?.querySelector(selector) ?? el.querySelector(selector);
}
/**
 * Troca chaves de `mls.*` por valores mockados; devolve uma função que restaura o estado original.
 * `cleanup()` também restaura qualquer troca pendente, então usar apenas trocarMls já é seguro
 * mesmo se o teste lançar antes de chamar o restaurador manualmente.
 */
export function trocarMls(overrides) {
    const chaves = Object.keys(overrides);
    for (const key of chaves) {
        const existia = key in mls;
        mlsBackup.push({ key, value: mls[key], existia });
        mls[key] = overrides[key];
    }
    return restaurarMls;
}
function restaurarMls() {
    while (mlsBackup.length) {
        const { key, value, existia } = mlsBackup.pop();
        if (existia)
            mls[key] = value;
        else
            delete mls[key];
    }
}
/** Remove todos os elementos montados e desfaz trocas de `mls.*` pendentes. Chamar ao fim de cada teste (try/finally). */
export function cleanup() {
    while (elementosMontados.length) {
        elementosMontados.pop()?.remove();
    }
    restaurarMls();
}
/**
 * Checagem universal de contrato (camada 1 da estratégia): elemento registrado e renderiza sem exceção.
 * Serve para qualquer um dos 88 plugins, independente do tipo.
 */
export async function montarEVerificar(tag, props = {}) {
    const registrado = !!customElements.get(tag);
    const el = await mount(tag, props);
    const renderizou = (el.shadowRoot?.childElementCount ?? 0) > 0 || el.childElementCount > 0;
    return { registrado, renderizou };
}
/**
 * Compara o valor obtido com o esperado (deep-equal com normalização) e lança um erro
 * formatado em caso de divergência — mantém a semântica "lançou = falhou" do runner ICAN.
 */
export function comparar(atual, expected, opts = {}) {
    const a = normalizar(atual);
    const e = normalizar(expected);
    if (opts.contains) {
        if (!contido(e, a))
            throw new Error(formatarDiff(a, e, true));
        return;
    }
    if (!deepEqual(a, e))
        throw new Error(formatarDiff(a, e, false));
}
function normalizar(valor) {
    if (typeof valor === 'string')
        return valor.replace(/\s+/g, ' ').trim();
    if (Array.isArray(valor))
        return valor.map(normalizar);
    if (valor && typeof valor === 'object') {
        const out = {};
        for (const key of Object.keys(valor).sort())
            out[key] = normalizar(valor[key]);
        return out;
    }
    return valor;
}
function deepEqual(a, b) {
    if (a === b)
        return true;
    if (typeof a !== typeof b || a === null || b === null)
        return false;
    if (typeof a === 'object') {
        const ka = Object.keys(a), kb = Object.keys(b);
        if (ka.length !== kb.length)
            return false;
        return ka.every((k) => deepEqual(a[k], b[k]));
    }
    return false;
}
function contido(esperadoParcial, atual) {
    if (esperadoParcial && typeof esperadoParcial === 'object' && !Array.isArray(esperadoParcial)) {
        if (!atual || typeof atual !== 'object')
            return false;
        return Object.keys(esperadoParcial).every((k) => contido(esperadoParcial[k], atual[k]));
    }
    return deepEqual(esperadoParcial, atual);
}
function formatarDiff(atual, expected, contains) {
    return `Esperado${contains ? ' (contém)' : ''}: ${JSON.stringify(expected)}\nObtido: ${JSON.stringify(atual)}`;
}
