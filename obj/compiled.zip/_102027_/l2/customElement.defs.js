"use strict";
/// <mls fileReference="_102027_/l2/customElement.defs.ts" enhancement="_blank" />
//# sourceMappingURL=customElement.defs.js.map