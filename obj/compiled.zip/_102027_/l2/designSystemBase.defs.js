"use strict";
/// <mls fileReference="_102027_/l2/designSystemBase.defs.ts" enhancement="_blank" />
//# sourceMappingURL=designSystemBase.defs.js.map