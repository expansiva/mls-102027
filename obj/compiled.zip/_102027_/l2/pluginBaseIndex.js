/// <mls fileReference="_102027_/l2/pluginBaseIndex.ts" enhancement="_blank"/>
export class PluginBaseIndex {
}
// this class is a abstract class, so use "disabled"
export default "disabled"; // or: export default new Pluginxxx()
