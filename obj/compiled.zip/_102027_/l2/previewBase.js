/// <mls fileReference="_102027_/l2/previewBase.ts" enhancement="_blank"/>
export class PreviewModeBase {
    constructor(_iFrame, _level, _isService, _storFile) {
        this.isService = false;
        this.storFile = undefined;
        this.iFrame = _iFrame;
        this.level = _level;
        this.isService = _isService;
        this.storFile = _storFile;
    }
}
