/// <mls fileReference="_102027_/l2/pluginBase.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { customElement, property } from 'lit/decorators.js';
let PluginBase = class PluginBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.scope = "";
    }
};
__decorate([
    property({ type: String })
], PluginBase.prototype, "scope", void 0);
PluginBase = __decorate([
    customElement('plugin-base-102027')
], PluginBase);
export { PluginBase };
