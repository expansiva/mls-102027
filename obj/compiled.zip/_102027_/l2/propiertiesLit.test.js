"use strict";
/// <mls fileReference="_102027_/l2/propiertiesLit.test.ts" enhancement="_blank" />
//# sourceMappingURL=propiertiesLit.test.js.map