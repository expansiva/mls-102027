/// <mls fileReference="_102027_/l2/queryAll.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=query-all.d.ts.map
