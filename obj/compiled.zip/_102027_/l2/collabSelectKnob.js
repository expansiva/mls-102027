/// <mls fileReference="_102027_/l2/collabSelectKnob.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let SelectOneKnobWidget = class SelectOneKnobWidget extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`@font-face{font-family:'Digital-7';src:url('l3/_100529_/fonts/digital-7.ttf') format('truetype')}collab-select-knob-102027 .widgets--select-one-knob-102020{position:relative;display:inline-flex;flex-direction:column;align-items:center;gap:8px;width:146px;outline:none;cursor:grab;user-select:none;-webkit-user-select:none}collab-select-knob-102027 .widgets--select-one-knob-102020:active{cursor:grabbing}collab-select-knob-102027 .widgets--select-one-knob-102020.is-disabled{opacity:.45;cursor:not-allowed;pointer-events:none}collab-select-knob-102027 .knob__ticks-ring{position:relative;width:146px;height:146px;border-radius:50%;flex-shrink:0}collab-select-knob-102027 .knob__tick{position:absolute;top:50%;left:50%;width:2px;height:4px;margin-left:-1px;margin-top:-62px;transform-origin:1px 62px;background:#2e2e45;background:var(--grey-color-dark);border-radius:1px;transition:background .12s ease}collab-select-knob-102027 .knob__tick.knob__tick--active{background:#4db8ff;box-shadow:0 0 5px rgba(77,184,255,0.7),0 0 10px rgba(77,184,255,0.7)}collab-select-knob-102027 .knob__body{position:absolute;top:50%;left:50%;width:68px;height:68px;margin-top:-34px;margin-left:-34px;border-radius:50%;background:radial-gradient(circle at 40% 30%, #3a404d 0%, #3a404d 30%, #3a404d 65%, #212733 100%);box-shadow:inset 0 2px 4px rgba(255,255,255,0.06),inset 0 -2px 5px rgba(0,0,0,0.7),0 0 0 6.4px #0c0c0c,0 0 0 10px #72728a,0 -3px 3px 10px #d0d0e0,0 4px 4px 10px #28283a,0 3px 2px 10px #48485e,-3px 0 3px 10px #90909e,5px 0 3px 10px #505060,0 0 0 11px #1e1e28;transition:transform .12s ease,box-shadow .12s ease;will-change:transform}collab-select-knob-102027 .knob__indicator{position:absolute;top:3px;left:50%;transform:translateX(-50%);width:4px;height:6px;border-radius:50%;background:#c1ffff;opacity:.3;transition:box-shadow .12s ease}collab-select-knob-102027 .knob__display{position:absolute;top:52%;left:50%;transform:translate(-50%, -50%);width:40px;height:35px;display:flex;align-items:center;justify-content:center;pointer-events:none;background:#232937;border-radius:5px;border:1px solid #232937;border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:13px;border-bottom-right-radius:13px;overflow:hidden}collab-select-knob-102027 .knob__value{font-family:'Digital-7','Courier New',monospace;font-size:30px;font-weight:700;color:#d3ffff;text-shadow:0 0 8px rgba(77,184,255,0.7),0 0 18px rgba(77,184,255,0.7);line-height:1;transition:opacity .2s ease,text-shadow .2s ease}collab-select-knob-102027 .knob__value.knob__value--hidden{visibility:hidden;opacity:0}collab-select-knob-102027 .widgets--select-one-knob-102020.is-active .knob__indicator{opacity:1;box-shadow:0 0 2px 1px rgba(255,255,255,0.5),0 0 5px 2px rgba(75,206,246,0.5),0 0 10px 3px #75eeff,0 0 18px 4px #4badff}@keyframes knob-blink{0%,100%{opacity:1}50%{opacity:.4}}collab-select-knob-102027 .widgets--select-one-knob-102020.is-typing .knob__display{animation:knob-blink .6s ease-in-out infinite}collab-select-knob-102027 .widgets--select-one-knob-102020.is-invalid .knob__value{color:#ff4d4d;text-shadow:0 0 8px rgba(255,77,77,0.7),0 0 16px rgba(255,77,77,0.4)}collab-select-knob-102027 .widgets--select-one-knob-102020.is-invalid .knob__display{animation:knob-blink .3s ease-in-out infinite;border-color:rgba(255,77,77,0.4)}`);
        this.min = 1;
        this.max = 9;
        this.value = null;
        this.step = 1;
        this.disabled = false;
        this.selected = false;
        this._focused = false;
        // --- drag state ---
        this._dragStartY = 0;
        this._dragStartValue = 0;
        this._dragging = false;
        // --- digit input state ---
        this._pendingDigit = '';
        this._digitTimeout = null;
        // exibe o dígito sendo digitado antes do timeout confirmar
        this._pendingDisplay = null;
        this._pendingInvalid = false;
    }
    // --- computed ---
    get _hasValue() {
        return this.value !== null && this.value !== undefined;
    }
    get _rotation() {
        if (!this._hasValue)
            return -135;
        const range = this.max - this.min;
        const normalized = ((this.value - this.min) / range);
        // arco de -135deg até +135deg (270deg total)
        return -135 + normalized * 270;
    }
    get _tickCount() {
        return Math.floor((this.max - this.min) / this.step) + 1;
    }
    // valor exibido no LCD: mostra dígito pendente durante digitação
    get _displayValue() {
        if (this._pendingDisplay !== null)
            return this._pendingDisplay;
        if (this._hasValue)
            return String(this.value);
        return '';
    }
    get _displayHidden() {
        return !this._hasValue && this._pendingDisplay === null;
    }
    // --- value helpers ---
    _clamp(v) {
        return Math.min(this.max, Math.max(this.min, v));
    }
    _setValue(next) {
        const prev = this.value;
        this.value = next !== null ? this._clamp(next) : null;
        if (this.value !== prev) {
            this.dispatchEvent(new CustomEvent('knob-change', {
                bubbles: true,
                composed: false,
                detail: { value: this.value, previous: prev }
            }));
        }
    }
    // --- keyboard ---
    _onKeyDown(e) {
        if (this.disabled)
            return;
        if (e.key === 'ArrowUp' || e.key === 'ArrowRight') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue((this._hasValue ? this.value : this.min - this.step) + this.step);
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue((this._hasValue ? this.value : this.min) - this.step);
            return;
        }
        if (e.key === 'Escape') {
            this._cancelDigitInput();
            this.renderRoot.blur?.();
            return;
        }
        if (e.key === 'Backspace') {
            e.preventDefault();
            this._cancelDigitInput();
            this._setValue(null);
            return;
        }
        // digit input
        if (/^[0-9]$/.test(e.key)) {
            e.preventDefault();
            this._pendingDigit += e.key;
            // atualiza display imediatamente com o dígito sendo digitado
            const parsed = parseInt(this._pendingDigit, 10);
            this._pendingDisplay = this._pendingDigit;
            this._pendingInvalid = parsed < this.min || parsed > this.max;
            if (this._digitTimeout)
                clearTimeout(this._digitTimeout);
            this._digitTimeout = setTimeout(() => {
                if (!isNaN(parsed) && parsed >= this.min && parsed <= this.max) {
                    this._setValue(parsed);
                }
                this._pendingDigit = '';
                this._pendingInvalid = false;
                this._pendingDisplay = null;
            }, 600);
        }
    }
    _cancelDigitInput() {
        if (this._digitTimeout)
            clearTimeout(this._digitTimeout);
        this._digitTimeout = null;
        this._pendingDigit = '';
        this._pendingDisplay = null;
        this._pendingInvalid = false;
    }
    // --- mouse drag ---
    _onMouseDown(e) {
        if (this.disabled)
            return;
        e.preventDefault();
        this._dragging = false;
        this._dragStartY = e.clientY;
        this._dragStartValue = this._hasValue ? this.value : this.min;
        const onMove = (ev) => {
            const delta = this._dragStartY - ev.clientY;
            if (Math.abs(delta) > 3)
                this._dragging = true;
            const steps = Math.round(delta / 8);
            this._setValue(this._dragStartValue + steps * this.step);
        };
        const onUp = () => {
            window.removeEventListener('mousemove', onMove);
            window.removeEventListener('mouseup', onUp);
            if (!this._dragging) {
                this.querySelector('[data-knob-root]')?.focus();
            }
            this._dragging = false;
        };
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
    }
    // --- scroll ---
    _onWheel(e) {
        if (this.disabled)
            return;
        e.preventDefault();
        const dir = e.deltaY < 0 ? 1 : -1;
        this._setValue((this._hasValue ? this.value : this.min) + dir * this.step);
    }
    // --- focus/blur ---
    _onFocus() {
        if (this.disabled)
            return;
        this._focused = true;
        this.dispatchEvent(new CustomEvent('knob-focus', { bubbles: true, composed: false }));
    }
    _onBlur() {
        this._focused = false;
        this._cancelDigitInput();
        this.dispatchEvent(new CustomEvent('knob-blur', { bubbles: true, composed: false }));
    }
    _onClick() {
        this.selected = !this.selected;
        this.requestUpdate();
        this.dispatchEvent(new CustomEvent('knob-click', { bubbles: true, composed: false }));
    }
    // --- ticks ---
    _renderTicks() {
        const ticks = [];
        const total = this._tickCount;
        for (let i = 0; i < total; i++) {
            const angle = -135 + (i / (total - 1)) * 270;
            const isCurrent = this._hasValue && (this.min + i * this.step) === this.value;
            ticks.push(html `
        <div
          class="knob__tick ${isCurrent ? 'knob__tick--active' : ''}"
          style="transform: rotate(${angle}deg)"
        ></div>
      `);
        }
        return ticks;
    }
    render() {
        const rootClasses = [
            'widgets--select-one-knob-102020',
            this.selected ? 'is-active' : '',
            this._focused ? 'is-focused' : '',
            this.disabled ? 'is-disabled' : '',
            this._hasValue ? 'has-value' : '',
            this._pendingDisplay !== null ? 'is-typing' : '',
            this._pendingInvalid ? 'is-invalid' : '',
        ].filter(Boolean).join(' ');
        return html `
      <div
        class="${rootClasses}"
        data-knob-root
        tabindex="${this.disabled ? -1 : 0}"
        role="spinbutton"
        aria-valuenow="${this._hasValue ? this.value : ''}"
        aria-valuemin="${this.min}"
        aria-valuemax="${this.max}"
        aria-disabled="${this.disabled}"
        @keydown="${this._onKeyDown}"
        @mousedown="${this._onMouseDown}"
        @wheel="${this._onWheel}"
        @focus="${this._onFocus}"
        @blur="${this._onBlur}"
        @click=${this._onClick}
      >
        <div class="knob__ticks-ring">
          ${this._renderTicks()}
        </div>

        <div
          class="knob__body"
          style="transform: rotate(${this._rotation}deg)"
        >
          <div class="knob__indicator"></div>
        </div>

        <div class="knob__display">
          <span class="knob__value ${this._displayHidden ? 'knob__value--hidden' : ''}">
            ${this._displayValue}
          </span>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "min", void 0);
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "max", void 0);
__decorate([
    property({ type: Number, reflect: true })
], SelectOneKnobWidget.prototype, "value", void 0);
__decorate([
    property({ type: Number })
], SelectOneKnobWidget.prototype, "step", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], SelectOneKnobWidget.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], SelectOneKnobWidget.prototype, "selected", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_focused", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_pendingDisplay", void 0);
__decorate([
    state()
], SelectOneKnobWidget.prototype, "_pendingInvalid", void 0);
SelectOneKnobWidget = __decorate([
    customElement('collab-select-knob-102027')
], SelectOneKnobWidget);
export { SelectOneKnobWidget };
