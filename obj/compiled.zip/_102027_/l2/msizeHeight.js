/// <mls fileReference="_102027_/l2/msizeHeight.ts" enhancement="_blank"/>
export function heightFromMsize(msize) {
    if (msize == null || msize === '')
        return null;
    const height = parseFloat(msize.split(',')[1] || '');
    if (!Number.isFinite(height) || height <= 0)
        return null;
    return height;
}
export function applyMsizeHeight(el, msize) {
    const height = heightFromMsize(msize);
    if (height == null)
        return false;
    el.style.height = height + 'px';
    el.style.overflow = 'auto';
    return true;
}
