"use strict";
/// <mls fileReference="_102027_/l2/litElement.defs.ts" enhancement="_blank" />
//# sourceMappingURL=litElement.defs.js.map