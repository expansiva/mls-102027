/// <mls fileReference="_102027_/l2/queryAsync.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=query-async.d.ts.map
