/// <mls shortName="reactiveElement" project="102027" enhancement="_blank" />
export * from '/_102027_/l2/cssTag.js';
//# sourceMappingURL=reactive-element.d.ts.map
