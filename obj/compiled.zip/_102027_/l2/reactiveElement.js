/// <mls fileReference="_102027_/l2/reactiveElement.ts" enhancement="_blank" />
export * from './cssTag.js';
//# sourceMappingURL=reactive-element.d.ts.map
//# sourceMappingURL=reactiveElement.js.map