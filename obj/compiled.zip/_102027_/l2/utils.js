/// <mls fileReference="_102027_/l2/utils.ts" enhancement="_blank" />
export function getPath(widget) {
    return mls.actual[0].setFullName(widget).getStorFileBase();
}
export function convertTagToFileName(tag) {
    const parts = tag.split('--');
    const namePart = parts.pop() || '';
    const folder = parts.join('/').replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    const regex = /(.+)-(\d+)$/;
    const match = namePart.match(regex);
    if (!match)
        return;
    const [, rest, number] = match;
    const shortName = rest.replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    return {
        shortName,
        project: +number,
        folder
    };
}
export function convertFileNameToTag(info) {
    const { shortName, project, folder = '' } = info;
    const kebabName = shortName.replace(/([A-Z])/g, '-$1').toLowerCase();
    const baseName = `${kebabName}-${project}`;
    const folderPrefix = folder ? folder.replace(/([A-Z])/g, '-$1').toLowerCase().replace(/\//g, '--') + '--' : '';
    return `${folderPrefix}${baseName}`;
}
export function setErrorOnModel(model, line, startColumn, endColumn, message, severity) {
    const lineIndent = getLineIndent(model, line);
    const markerOptions = {
        severity,
        message,
        startLineNumber: line,
        startColumn: startColumn + lineIndent,
        endLineNumber: line,
        endColumn: endColumn + lineIndent,
    };
    monaco.editor.setModelMarkers(model, 'markerSource', [markerOptions]);
}
function getLineIndent(model, lineNumber) {
    if (model) {
        var lineContent = model.getLineContent(lineNumber);
        var match = lineContent.match(/^\s*/);
        return match ? match[0].length : 0;
    }
    return 0;
}
//# sourceMappingURL=utils.js.map