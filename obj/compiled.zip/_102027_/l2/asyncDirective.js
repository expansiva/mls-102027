/// <mls fileReference="_102027_/l2/asyncDirective.ts" enhancement="_blank" />
export * from './directive.js';
//# sourceMappingURL=asyncDirective.js.map