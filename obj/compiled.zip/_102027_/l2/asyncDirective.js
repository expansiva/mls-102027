/// <mls shortName="asyncDirective" project="102027" enhancement="_blank" />
export * from '/_102027_/l2/directive.js';
