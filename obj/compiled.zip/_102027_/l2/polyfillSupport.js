/// <mls shortName="polyfillSupport" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=polyfill-support.d.ts.map
