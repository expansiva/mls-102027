/// <mls shortName="eventOptions" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=event-options.d.ts.map
