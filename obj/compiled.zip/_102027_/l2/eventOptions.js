/// <mls fileReference="_102027_/l2/eventOptions.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=event-options.d.ts.map
