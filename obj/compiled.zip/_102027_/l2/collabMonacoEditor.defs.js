"use strict";
/// <mls fileReference="_102027_/l2/collabMonacoEditor.defs.ts" enhancement="_blank"/>
//# sourceMappingURL=collabMonacoEditor.defs.js.map