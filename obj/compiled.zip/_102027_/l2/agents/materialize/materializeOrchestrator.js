/// <mls fileReference="_102027_/l2/agents/materialize/materializeOrchestrator.ts" enhancement="_blank"/>
import { getMaterializeIndex } from '/_102027_/l2/defsAST.js';
import { collabImport } from '/_102027_/l2/collabImport.js';
const cacheMaterializeOrchestrator = new Map();
export function getMaterializeOrchestrator(defPath) {
    if (!cacheMaterializeOrchestrator.has(defPath)) {
        const orchestrator = new MaterializeOrchestrator(defPath);
        orchestrator.onAllCompleted = () => {
            cacheMaterializeOrchestrator.delete(defPath);
        };
        cacheMaterializeOrchestrator.set(defPath, orchestrator);
    }
    return cacheMaterializeOrchestrator.get(defPath);
}
export class MaterializeOrchestrator {
    constructor(jsonPath) {
        this.jsonPath = jsonPath;
        this.items = [];
        this.completedIds = new Set();
        this.onAllCompleted = null;
    }
    async loadItems() {
        const sfInfo = await mls.stor.convertFileReferenceToFile(this.jsonPath);
        if (!sfInfo)
            return;
        const key = mls.stor.getKeyToFile(sfInfo);
        const sf = mls.stor.files[key];
        if (!sf)
            return;
        const data = await sf.getContent();
        this.items = getMaterializeIndex(data);
    }
    isAllCompleted() {
        return (this.items.length > 0 &&
            this.items.every((item) => this.completedIds.has(item.id)));
    }
    async process(trigger) {
        if (!this.items.length)
            await this.loadItems();
        if (trigger === 'init') {
            return this.items.filter((item) => item.dependsOn.length === 0);
        }
        this.completedIds.add(trigger);
        if (this.isAllCompleted()) {
            this.onAllCompleted?.();
            return [];
        }
        return this.items.filter((item) => {
            if (!item.dependsOn.includes(trigger))
                return false;
            if (this.completedIds.has(item.id))
                return false;
            if (item.dependsOn.length === 0)
                return false;
            return item.dependsOn.every((dep) => this.completedIds.has(dep));
        });
    }
    getStatus() {
        return {
            total: this.items.length,
            completed: this.completedIds.size,
            pending: this.items.length - this.completedIds.size,
            completedIds: [...this.completedIds],
            pendingIds: this.items
                .filter((item) => !this.completedIds.has(item.id))
                .map((item) => item.id),
            isAllCompleted: this.isAllCompleted(),
        };
    }
    reset() {
        this.completedIds.clear();
    }
    async getSkill(path) {
        try {
            if (path.startsWith('/'))
                path = path.slice(1);
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return '';
            const module = await collabImport(f);
            if (!module) {
                console.info(`[getSkill]Módulo não registrado: ${path}`);
                return '';
            }
            let src = module.skill;
            return await this.processTemplate(src);
        }
        catch (err) {
            console.error(`Erro em ${path}`, err);
            return '';
        }
    }
    async processTemplate(input) {
        const regex = /\[\[\((.*?)\)\.(.*?)\]\]/g;
        let result = input;
        const matches = [...input.matchAll(regex)];
        for (const match of matches) {
            const fullMatch = match[0];
            const filePath = match[1];
            const expression = match[2];
            const isFunction = expression.endsWith("()");
            const exportName = isFunction
                ? expression.replace("()", "")
                : expression;
            try {
                const f = mls.stor.convertFileReferenceToFile(filePath);
                if (!f)
                    continue;
                const module = await collabImport(f);
                if (!module) {
                    console.info(`Módulo não registrado: ${filePath}`);
                    continue;
                }
                let replacement;
                if (isFunction) {
                    replacement = await module[exportName]();
                }
                else {
                    replacement = module[exportName];
                }
                result = result.replace(fullMatch, String(replacement));
            }
            catch (err) {
                console.error(`Erro em ${fullMatch}`, err);
            }
        }
        return result;
    }
    async processGroup(trigger) {
        if (!this.items.length)
            await this.loadItems();
        if (trigger === 'init') {
            return this.groupByAgent(this.items.filter((item) => item.dependsOn.length === 0));
        }
        this.completedIds.add(trigger);
        if (this.isAllCompleted()) {
            this.onAllCompleted?.();
            return {};
        }
        return this.groupByAgent(this.items.filter((item) => {
            if (!item.dependsOn.includes(trigger))
                return false;
            if (this.completedIds.has(item.id))
                return false;
            if (item.dependsOn.length === 0)
                return false;
            return item.dependsOn.every((dep) => this.completedIds.has(dep));
        }));
    }
    groupByAgent(tasks) {
        return tasks.reduce((acc, task) => {
            if (!acc[task.agent])
                acc[task.agent] = [];
            acc[task.agent].push(task);
            return acc;
        }, {});
    }
    async getVar(path, variable) {
        try {
            const f = mls.stor.convertFileReferenceToFile(path);
            if (!f)
                return '';
            const module = await collabImport(f);
            if (!module) {
                console.info(`Módulo não registrado: ${path}`);
                return '';
            }
            if (!module[variable]) {
                console.info(`Variable não registrado: ${path}; ${variable}`);
                return '';
            }
            let result = module[variable];
            if (typeof result === 'object') {
                return JSON.stringify(result);
            }
            return result;
        }
        catch (err) {
            console.error(`Erro em ${path}`, err);
            return '';
        }
    }
}
