/// <mls fileReference="_102027_/l2/agents/materialize/agentMaterializePlanner.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { appendLongTermMemory } from '/_100554_/l2/aiAgentHelper.js';
export function createAgent() {
    return {
        agentName: "agentMaterializePlanner",
        agentProject: 102027,
        agentFolder: "",
        agentDescription: "First agent for general materialize",
        visibility: "public",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const system = await prepareSystemPrompt();
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system,
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `New module`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (!payload || !payload.type)
        throw new Error(`Payload invalid`);
    if (!['flexible', 'result'].includes(payload?.type))
        throw new Error(`Payload type invalid: ${payload?.type}`);
    let status = 'completed';
    let intents = [];
    if (context.isTest) {
        console.info(payload);
        return [{
                type: 'update-status',
                hookSequential,
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: 1,
                stepId: parentStep.stepId,
                status: 'completed'
            }];
    }
    if (payload.type === 'flexible') {
        await appendLongTermMemory(context, { "moduleName": "pizzaria" });
        const ag = extractObjectFromString(payload.result.prompt) || '[]';
        const newStep = {
            type: "add-step",
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: 1,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: 'agentMaterialize',
                //prompt: '@@' + payload.result.prompt,
                prompt: JSON.parse(ag)[0].toString(),
                rags: payload.result.rags,
            },
            //executionMode: {type:'parallel', args:JSON.parse(ag)}
        };
        intents.push(newStep);
    }
    if (payload.type === 'result') {
        const updateStatusAgent = {
            type: 'update-status',
            hookSequential,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: 1,
            stepId: parentStep.stepId,
            status: 'completed'
        };
        intents.push(updateStatusAgent);
    }
    intents = [...intents];
    return intents;
}
async function prepareSystemPrompt() {
    let system = system1;
    system = system1.replace('{{agentsAvaliables}}', JSON.stringify([{ agent: 'agentMaterialize', description: 'Inicializa o processo de materialize' },]));
    return system;
}
function extractObjectFromString(input) {
    const match = input.match(/[\[\{][\s\S]*[\]\}]/);
    return match ? match[0] : null;
}
const system1 = `
<!-- modelType: codeflash -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) or nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10, code2 (kimi 2.5) -->

You are a coordinator of agents responsible for executing tasks based on the user's prompt.  
Your only goal at this moment is to classify the type of action required from the prompt.
If you are unable to classify, send the first agent.

## Available Agents
{{agentsAvaliables}}


## Output format
Return only valid JSON in the following structure:

[[OutputSection1]]

`;
//#endregion
