"use strict";
/// <mls shortName="static" project="102027" enhancement="_blank" folder="" />
