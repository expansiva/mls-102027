/// <mls fileReference="_102027_/l2/litHtml.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=lit-html.d.ts.map
