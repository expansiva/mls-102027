/// <mls shortName="templateContent" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=template-content.d.ts.map
