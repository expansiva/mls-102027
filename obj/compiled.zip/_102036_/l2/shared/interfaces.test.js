/// <mls fileReference="_102036_/l2/shared/interfaces.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
